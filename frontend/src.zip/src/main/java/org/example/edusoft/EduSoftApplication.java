package org.example.edusoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduSoftApplication {

    public static void main(String[] args) {
        SpringApplication.run(EduSoftApplication.class, args);
    }

}
