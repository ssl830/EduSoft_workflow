package org.example.edusoft.entity;

import lombok.Data;

@Data
public class Class {
    private Long id;
    private Long courseId;
    private String name;
    private String classCode;
} 