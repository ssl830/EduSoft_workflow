package org.example.edusoft.entity;

import lombok.Data;

@Data
public class FavoriteQuestion {
    private Long studentId;
    private Long questionId;
} 